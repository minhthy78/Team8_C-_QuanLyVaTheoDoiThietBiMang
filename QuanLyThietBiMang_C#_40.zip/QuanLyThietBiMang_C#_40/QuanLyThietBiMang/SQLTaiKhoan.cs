﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public class SQLTaiKhoan
    {
        private SqlConnection ketnoi;
        public SQLTaiKhoan()
        {
            this.ketnoi = KetNoiSQL.GetConnection();
        }

        public bool Login(string username, string password)
        {
            bool kqLogin = false;

            try
            {
                using (SqlCommand thutuc = new SqlCommand("sp_TaiKhoan_CheckLogin", ketnoi))
                {
                    thutuc.CommandType = System.Data.CommandType.StoredProcedure;
                    thutuc.Parameters.AddWithValue("@Username", username);
                    thutuc.Parameters.AddWithValue("@Password", password);

                    thutuc.ExecuteNonQuery();

                    using (SqlDataReader reader = thutuc.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int columnIndex = reader.GetOrdinal("KetQua");
                            kqLogin = Convert.ToBoolean(reader.GetValue(columnIndex));

                            if (kqLogin)
                            {
                                string hoten = reader.GetString(reader.GetOrdinal("HoTen"));
                                string email = reader.GetString(reader.GetOrdinal("Email"));
                                bool vaitro = reader.GetBoolean(reader.GetOrdinal("VaiTro"));

                                TaiKhoan taikhoan = new TaiKhoan
                                {
                                    Username = username,
                                    HoTen = hoten,
                                    Email = email,
                                    VaiTro = vaitro
                                };

                                // Lưu vào bộ nhớ tạm
                                BoNhoTam.SetUser(taikhoan);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi sql login: " + ex.Message);
            }

            return kqLogin;
        }


        public List<TaiKhoan> GetAll()
        {
            List<TaiKhoan> dsTaiKhoan = new List<TaiKhoan>();
            try
            {
                using (SqlCommand command = new SqlCommand("sp_TaiKhoan_SelectAll", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //ketnoi.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string username = reader["Username"].ToString();
                            string hoTen = reader["HoTen"].ToString();
                            string email = reader["Email"].ToString();
                            bool vaiTro = Convert.ToBoolean(reader["VaiTro"]);

                            TaiKhoan taiKhoan = new TaiKhoan();
                            taiKhoan.Username = username;
                            taiKhoan.HoTen = hoTen;
                            taiKhoan.Email = email;
                            taiKhoan.VaiTro = vaiTro;

                            dsTaiKhoan.Add(taiKhoan);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
            return dsTaiKhoan;
        }

        public void Insert(string username, string password, string hoten, string email, bool vaitro)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_TaiKhoan_Insert", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@HoTen", hoten);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@VaiTro", vaitro);

                  
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
        }

        public void Update(string username, string hoten, string email, bool vaitro)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_TaiKhoan_Update", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@HoTen", hoten);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@VaiTro", vaitro);

                    
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
        }

        public void Delete(string username)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_TaiKhoan_Delete", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", username);

                   
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
        }

        public void DoiMatKhau(string username, string password)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_TaiKhoan_ChangePassword", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);  
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
        }

    }


}
