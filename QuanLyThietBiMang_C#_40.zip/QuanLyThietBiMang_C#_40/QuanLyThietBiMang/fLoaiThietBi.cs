﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fLoaiThietBi : Form
    {
        public fLoaiThietBi()
        {
            InitializeComponent();
            this.Load += FLoaiThietBi_Load;
        }
        private void FLoaiThietBi_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTenLoai.Text))
            {
                MessageBox.Show("Vui lòng nhập tên loại thiết bị.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SQLLoaiThietBi sqlLoai = new SQLLoaiThietBi();
            sqlLoai.Insert(txtTenLoai.Text);
            txtTenLoai.Text = "";
            LoadData();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            SQLLoaiThietBi sqlLoai = new SQLLoaiThietBi();

            // Kiểm tra xem có dòng nào được chọn không
            if (tblLoai.SelectedRows.Count > 0)
            {
                // Lấy thông tin từ dòng được chọn
                int dongDangChon = tblLoai.SelectedRows[0].Index;
                int maUpdate = (int)tblLoai.Rows[dongDangChon].Cells["MaLoai"].Value;
                string tenUpdate = (string)tblLoai.Rows[dongDangChon].Cells["TenLoai"].Value;

                // Gọi phương thức update từ SQLLoaiThietBi
                sqlLoai.Update(maUpdate, tenUpdate);

                // Tải lại dữ liệu
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem có dòng nào được chọn không
            if (tblLoai.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn loại thiết bị cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy mã loại thiết bị từ dòng được chọn
            int maXoa = (int)tblLoai.SelectedRows[0].Cells["MaLoai"].Value;

            // Xác nhận xóa
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa loại thiết bị này không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                SQLLoaiThietBi sqlLoai = new SQLLoaiThietBi();
                sqlLoai.Delete(maXoa);
                LoadData();
            }
        }
        private void LoadData()
        {
            // Lấy danh sách loại từ SQL 
            SQLLoaiThietBi sqlLoai = new SQLLoaiThietBi();
            List<LoaiThietBi> dsLoai = sqlLoai.GetAll();
            tblLoai.Rows.Clear();
            // Thêm dsLoai vào bảng Loại
            foreach (LoaiThietBi loai in dsLoai)
            {
                tblLoai.Rows.Add(loai.GetMaLoai(), loai.GetTenLoai());
            }
  
          
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
