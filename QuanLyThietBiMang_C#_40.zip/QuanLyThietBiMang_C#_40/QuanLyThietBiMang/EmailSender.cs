﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;

namespace QuanLyThietBiMang
{
    public class EmailSender
    {
        private string email;
        private string password;
        private SmtpClient smtpClient;

        public EmailSender(string mail, string pass)
        {
            this.email = mail;
            this.password = pass;

            smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(email, password),
                EnableSsl = true
            };
        }

        public void SendEmail(string to, string subject, string message)
        {
            try
            {
                MailMessage emailMessage = new MailMessage(email, to, subject, message);

                smtpClient.Send(emailMessage);
                Console.WriteLine("Email sent successfully.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error sending email: {e.Message}");
            }
        }

        public void SendEmailToGroup(string[] to, string subject, string message)
        {
            try
            {
                MailMessage emailMessage = new MailMessage(email, to[0], subject, message);

                for (int i = 1; i < to.Length; i++)
                {
                    emailMessage.To.Add(to[i]);
                }

                smtpClient.Send(emailMessage);
                Console.WriteLine("Email sent successfully.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error sending email: {e.Message}");
            }
        }
    }
}
