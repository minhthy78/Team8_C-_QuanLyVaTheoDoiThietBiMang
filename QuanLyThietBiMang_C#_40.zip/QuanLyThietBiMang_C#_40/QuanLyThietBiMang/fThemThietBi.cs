﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fThemThietBi : Form
    {
        public fThemThietBi()
        {
            InitializeComponent();
            //this.Load += fThemThietBi_Load;  
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Xử lý khi nút Thêm được nhấp
            LoaiThietBi loai = (LoaiThietBi)cbLoai.SelectedItem;
            Khu khu = (Khu)cbKhu.SelectedItem;

            // Thêm thiết bị vào cơ sở dữ liệu
            SQLThietBi tb = new SQLThietBi();
            tb.Insert(txtTen.Text, txtIP.Text, khu.GetMaKhu(), loai.GetMaLoai());

            // Hiển thị thông báo
            MessageBox.Show("Đã thêm thiết bị");

            // Reset các trường nhập liệu và đặt focus vào ô Tên
            txtTen.Text = "";
            txtIP.Text = "";
            cbKhu.SelectedIndex = -1;
            cbLoai.SelectedIndex = -1;
            txtTen.Focus();

            this.Close();

        }

        private void LoadData()
        {
            SQLKhu sqlKhu = new SQLKhu();
            List<Khu> dsKhu = sqlKhu.GetAll();
            foreach (Khu item in dsKhu)
            {
                cbKhu.Items.Add(item);
            }
            cbKhu.SelectedIndex = -1;

            SQLLoaiThietBi sqlLoai = new SQLLoaiThietBi();
            List<LoaiThietBi> dsLoai = sqlLoai.GetAll();
            foreach (LoaiThietBi item in dsLoai)
            {
                cbLoai.Items.Add(item);
            }
            cbLoai.SelectedIndex = -1;
        }

        private void fThemThietBi_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
