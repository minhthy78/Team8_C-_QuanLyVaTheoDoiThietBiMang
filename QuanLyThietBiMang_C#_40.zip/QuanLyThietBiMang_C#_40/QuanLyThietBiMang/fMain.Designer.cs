﻿
namespace QuanLyThietBiMang
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.sidebar = new System.Windows.Forms.Panel();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnXemLog = new System.Windows.Forms.Button();
            this.btnCaiDatMail = new System.Windows.Forms.Button();
            this.btnQuanLyKhu = new System.Windows.Forms.Button();
            this.btnQuanLyLoai = new System.Windows.Forms.Button();
            this.btnQuanLyTaiKhoan = new System.Windows.Forms.Button();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menuButton = new System.Windows.Forms.PictureBox();
            this.sidebarTimer = new System.Windows.Forms.Timer(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.prgKiemTra = new System.Windows.Forms.ProgressBar();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnStop = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnPing = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnXoa = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnSua = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnThem = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.grpNhatKyKiemTra = new System.Windows.Forms.GroupBox();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.tblThietBi = new System.Windows.Forms.DataGridView();
            this.colMa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timerProgress = new System.Windows.Forms.Timer(this.components);
            this.sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuButton)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel13.SuspendLayout();
            this.grpNhatKyKiemTra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblThietBi)).BeginInit();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(29)))), ((int)(((byte)(136)))));
            this.sidebar.Controls.Add(this.btnThoat);
            this.sidebar.Controls.Add(this.btnXemLog);
            this.sidebar.Controls.Add(this.btnCaiDatMail);
            this.sidebar.Controls.Add(this.btnQuanLyKhu);
            this.sidebar.Controls.Add(this.btnQuanLyLoai);
            this.sidebar.Controls.Add(this.btnQuanLyTaiKhoan);
            this.sidebar.Controls.Add(this.lblHoTen);
            this.sidebar.Controls.Add(this.pictureBox1);
            this.sidebar.Controls.Add(this.panel2);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.MaximumSize = new System.Drawing.Size(287, 699);
            this.sidebar.MinimumSize = new System.Drawing.Size(80, 629);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(287, 699);
            this.sidebar.TabIndex = 0;
            this.sidebar.SizeChanged += new System.EventHandler(this.sidebar_SizeChanged);
            // 
            // btnThoat
            // 
            this.btnThoat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThoat.FlatAppearance.BorderSize = 0;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.White;
            this.btnThoat.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_log_out_48;
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat.Location = new System.Drawing.Point(1, 577);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(286, 59);
            this.btnThoat.TabIndex = 3;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnXemLog
            // 
            this.btnXemLog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXemLog.FlatAppearance.BorderSize = 0;
            this.btnXemLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemLog.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemLog.ForeColor = System.Drawing.Color.White;
            this.btnXemLog.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_eye_48;
            this.btnXemLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXemLog.Location = new System.Drawing.Point(0, 523);
            this.btnXemLog.Name = "btnXemLog";
            this.btnXemLog.Size = new System.Drawing.Size(287, 52);
            this.btnXemLog.TabIndex = 0;
            this.btnXemLog.Text = "Xem Log";
            this.btnXemLog.UseVisualStyleBackColor = true;
            this.btnXemLog.Click += new System.EventHandler(this.btnXemLog_Click);
            // 
            // btnCaiDatMail
            // 
            this.btnCaiDatMail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCaiDatMail.FlatAppearance.BorderSize = 0;
            this.btnCaiDatMail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaiDatMail.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaiDatMail.ForeColor = System.Drawing.Color.White;
            this.btnCaiDatMail.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_message_settings_48;
            this.btnCaiDatMail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCaiDatMail.Location = new System.Drawing.Point(3, 457);
            this.btnCaiDatMail.Name = "btnCaiDatMail";
            this.btnCaiDatMail.Size = new System.Drawing.Size(284, 52);
            this.btnCaiDatMail.TabIndex = 0;
            this.btnCaiDatMail.Text = "Cài Đặt Email";
            this.btnCaiDatMail.UseVisualStyleBackColor = true;
            this.btnCaiDatMail.Click += new System.EventHandler(this.btnCaiDatMail_Click);
            // 
            // btnQuanLyKhu
            // 
            this.btnQuanLyKhu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuanLyKhu.FlatAppearance.BorderSize = 0;
            this.btnQuanLyKhu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanLyKhu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyKhu.ForeColor = System.Drawing.Color.White;
            this.btnQuanLyKhu.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_area_48;
            this.btnQuanLyKhu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanLyKhu.Location = new System.Drawing.Point(0, 389);
            this.btnQuanLyKhu.Name = "btnQuanLyKhu";
            this.btnQuanLyKhu.Size = new System.Drawing.Size(287, 52);
            this.btnQuanLyKhu.TabIndex = 0;
            this.btnQuanLyKhu.Text = "Quản Lý Khu";
            this.btnQuanLyKhu.UseVisualStyleBackColor = true;
            this.btnQuanLyKhu.Click += new System.EventHandler(this.btnQuanLyKhu_Click);
            // 
            // btnQuanLyLoai
            // 
            this.btnQuanLyLoai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuanLyLoai.FlatAppearance.BorderSize = 0;
            this.btnQuanLyLoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanLyLoai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyLoai.ForeColor = System.Drawing.Color.White;
            this.btnQuanLyLoai.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_device_48;
            this.btnQuanLyLoai.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanLyLoai.Location = new System.Drawing.Point(0, 320);
            this.btnQuanLyLoai.Name = "btnQuanLyLoai";
            this.btnQuanLyLoai.Size = new System.Drawing.Size(287, 60);
            this.btnQuanLyLoai.TabIndex = 0;
            this.btnQuanLyLoai.Text = "Loại Thiết Bị";
            this.btnQuanLyLoai.UseVisualStyleBackColor = true;
            this.btnQuanLyLoai.Click += new System.EventHandler(this.btnQuanLyLoai_Click);
            // 
            // btnQuanLyTaiKhoan
            // 
            this.btnQuanLyTaiKhoan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuanLyTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btnQuanLyTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanLyTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyTaiKhoan.ForeColor = System.Drawing.Color.White;
            this.btnQuanLyTaiKhoan.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_account_481;
            this.btnQuanLyTaiKhoan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanLyTaiKhoan.Location = new System.Drawing.Point(1, 256);
            this.btnQuanLyTaiKhoan.Name = "btnQuanLyTaiKhoan";
            this.btnQuanLyTaiKhoan.Size = new System.Drawing.Size(286, 61);
            this.btnQuanLyTaiKhoan.TabIndex = 0;
            this.btnQuanLyTaiKhoan.Text = "Tài Khoản";
            this.btnQuanLyTaiKhoan.UseVisualStyleBackColor = true;
            this.btnQuanLyTaiKhoan.Click += new System.EventHandler(this.btnQuanLyTaiKhoan_Click);
            // 
            // lblHoTen
            // 
            this.lblHoTen.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHoTen.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTen.ForeColor = System.Drawing.Color.Transparent;
            this.lblHoTen.Location = new System.Drawing.Point(0, 47);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(287, 41);
            this.lblHoTen.TabIndex = 1;
            this.lblHoTen.Text = "___";
            this.lblHoTen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::QuanLyThietBiMang.Properties.Resources.id;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(287, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.menuButton);
            this.panel2.Location = new System.Drawing.Point(0, 154);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(287, 80);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(101, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "Menu";
            // 
            // menuButton
            // 
            this.menuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuButton.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_menu_48;
            this.menuButton.Location = new System.Drawing.Point(12, 20);
            this.menuButton.Name = "menuButton";
            this.menuButton.Size = new System.Drawing.Size(53, 39);
            this.menuButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuButton.TabIndex = 0;
            this.menuButton.TabStop = false;
            this.menuButton.Click += new System.EventHandler(this.menuButton_Click);
            // 
            // sidebarTimer
            // 
            this.sidebarTimer.Interval = 10;
            this.sidebarTimer.Tick += new System.EventHandler(this.sidebarTimer_Tick);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(80)))), ((int)(((byte)(163)))));
            this.panel3.Controls.Add(this.prgKiemTra);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(287, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1062, 44);
            this.panel3.TabIndex = 1;
            // 
            // prgKiemTra
            // 
            this.prgKiemTra.Location = new System.Drawing.Point(767, 31);
            this.prgKiemTra.Name = "prgKiemTra";
            this.prgKiemTra.Size = new System.Drawing.Size(277, 10);
            this.prgKiemTra.TabIndex = 5;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btnStop);
            this.panel12.Location = new System.Drawing.Point(560, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(113, 38);
            this.panel12.TabIndex = 3;
            // 
            // btnStop
            // 
            this.btnStop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStop.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_stop_24;
            this.btnStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStop.Location = new System.Drawing.Point(-2, -14);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(123, 63);
            this.btnStop.TabIndex = 0;
            this.btnStop.Text = "Dừng";
            this.btnStop.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btnPing);
            this.panel11.Location = new System.Drawing.Point(412, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(141, 38);
            this.panel11.TabIndex = 4;
            // 
            // btnPing
            // 
            this.btnPing.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPing.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPing.ForeColor = System.Drawing.Color.White;
            this.btnPing.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_check_24;
            this.btnPing.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPing.Location = new System.Drawing.Point(-6, -14);
            this.btnPing.Name = "btnPing";
            this.btnPing.Size = new System.Drawing.Size(149, 63);
            this.btnPing.TabIndex = 0;
            this.btnPing.Text = "Kiểm tra";
            this.btnPing.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPing.UseVisualStyleBackColor = true;
            this.btnPing.Click += new System.EventHandler(this.btnPing_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btnXoa);
            this.panel10.Location = new System.Drawing.Point(286, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(97, 38);
            this.panel10.TabIndex = 4;
            // 
            // btnXoa
            // 
            this.btnXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.Color.White;
            this.btnXoa.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_delete_24;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(-2, -15);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(110, 63);
            this.btnXoa.TabIndex = 0;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btnSua);
            this.panel9.Location = new System.Drawing.Point(162, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(97, 38);
            this.panel9.TabIndex = 3;
            // 
            // btnSua
            // 
            this.btnSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.Color.White;
            this.btnSua.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_edit_24;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(-2, -15);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(110, 63);
            this.btnSua.TabIndex = 0;
            this.btnSua.Text = "Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnThem);
            this.panel8.Location = new System.Drawing.Point(34, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(113, 38);
            this.panel8.TabIndex = 2;
            // 
            // btnThem
            // 
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = global::QuanLyThietBiMang.Properties.Resources.icons8_plus_24;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(-2, -14);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(122, 63);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.grpNhatKyKiemTra);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel13.Location = new System.Drawing.Point(1051, 44);
            this.panel13.MaximumSize = new System.Drawing.Size(316, 654);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(298, 654);
            this.panel13.TabIndex = 2;
            // 
            // grpNhatKyKiemTra
            // 
            this.grpNhatKyKiemTra.Controls.Add(this.txtLog);
            this.grpNhatKyKiemTra.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNhatKyKiemTra.Location = new System.Drawing.Point(3, 0);
            this.grpNhatKyKiemTra.Name = "grpNhatKyKiemTra";
            this.grpNhatKyKiemTra.Size = new System.Drawing.Size(288, 655);
            this.grpNhatKyKiemTra.TabIndex = 0;
            this.grpNhatKyKiemTra.TabStop = false;
            this.grpNhatKyKiemTra.Text = "Nhật ký kiểm tra: ";
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(3, 22);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(283, 635);
            this.txtLog.TabIndex = 0;
            // 
            // tblThietBi
            // 
            this.tblThietBi.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(255)))));
            this.tblThietBi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblThietBi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMa,
            this.Column2,
            this.colIP,
            this.Column4,
            this.Column5,
            this.colTinhTrang});
            this.tblThietBi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblThietBi.Location = new System.Drawing.Point(287, 44);
            this.tblThietBi.Name = "tblThietBi";
            this.tblThietBi.RowHeadersWidth = 51;
            this.tblThietBi.RowTemplate.Height = 24;
            this.tblThietBi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblThietBi.Size = new System.Drawing.Size(764, 655);
            this.tblThietBi.TabIndex = 3;
            // 
            // colMa
            // 
            this.colMa.DataPropertyName = "MaThietBi";
            this.colMa.HeaderText = "Mã";
            this.colMa.MinimumWidth = 6;
            this.colMa.Name = "colMa";
            this.colMa.Width = 125;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "TenThietBi";
            this.Column2.HeaderText = "Tên Thiết Bị";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // colIP
            // 
            this.colIP.DataPropertyName = "IP";
            this.colIP.HeaderText = "IP";
            this.colIP.MinimumWidth = 6;
            this.colIP.Name = "colIP";
            this.colIP.Width = 125;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "TenLoai";
            this.Column4.HeaderText = "Loại";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 125;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "TenKhu";
            this.Column5.HeaderText = "Khu";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 125;
            // 
            // colTinhTrang
            // 
            this.colTinhTrang.DataPropertyName = "TinhTrang";
            this.colTinhTrang.HeaderText = "Online";
            this.colTinhTrang.MinimumWidth = 6;
            this.colTinhTrang.Name = "colTinhTrang";
            this.colTinhTrang.Width = 125;
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1349, 699);
            this.Controls.Add(this.tblThietBi);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.sidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1349, 699);
            this.Name = "fMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.fMain_Load);
            this.sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuButton)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.grpNhatKyKiemTra.ResumeLayout(false);
            this.grpNhatKyKiemTra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblThietBi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidebar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnXemLog;
        private System.Windows.Forms.Button btnCaiDatMail;
        private System.Windows.Forms.Button btnQuanLyKhu;
        private System.Windows.Forms.Button btnQuanLyLoai;
        private System.Windows.Forms.PictureBox menuButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer sidebarTimer;
        private System.Windows.Forms.Button btnQuanLyTaiKhoan;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnPing;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.GroupBox grpNhatKyKiemTra;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.DataGridView tblThietBi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTinhTrang;
        private System.Windows.Forms.ProgressBar prgKiemTra;
        private System.Windows.Forms.Timer timerProgress;
        private System.Windows.Forms.Button btnThoat;
    }
}