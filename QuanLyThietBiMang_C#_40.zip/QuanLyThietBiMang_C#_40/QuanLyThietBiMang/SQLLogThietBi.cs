﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace QuanLyThietBiMang
{
    public class SQLLogThietBi
    {
        private SqlConnection ketnoi;

        public SQLLogThietBi()
        {
            this.ketnoi = KetNoiSQL.GetConnection();
        }

        public void Insert(int mathietbi, bool tinhtrang)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_LogThietBi_Insert", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaThietBi", mathietbi);
                    cmd.Parameters.AddWithValue("@TinhTrang", tinhtrang);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public List<LogThietBi> GetAll()
        {
            List<LogThietBi> dsLog = new List<LogThietBi>();
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_Log_SelectAll", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(reader.GetOrdinal("MaThietBi"));
                            string name = reader.GetString(reader.GetOrdinal("TenThietBi"));
                            bool status = reader.GetBoolean(reader.GetOrdinal("TinhTrang"));
                            string ip = reader.GetString(reader.GetOrdinal("Ip"));
                            string khu = reader.GetString(reader.GetOrdinal("MaKhu"));
                            int loai = reader.GetInt32(reader.GetOrdinal("LoaiThietBi"));
                            string tenKhu = reader.GetString(reader.GetOrdinal("TenKhu"));
                            string tenLoai = reader.GetString(reader.GetOrdinal("TenLoai"));
                            DateTime thoiGian = reader.GetDateTime(reader.GetOrdinal("ThoiGian"));

                            ThietBi thietbi = new ThietBi();
                            thietbi.SetIp(ip);
                            thietbi.SetMa(id);

                            thietbi.SetTinhTrang(status);
                            thietbi.SetTen(name);
                            thietbi.SetKhu(khu);
                            thietbi.SetLoai(loai);
                            thietbi.SetTenKhu(tenKhu);
                            thietbi.SetTenLoai(tenLoai);
                            

                            LogThietBi log = new LogThietBi(thietbi, thoiGian);
                            dsLog.Add(log);
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            return dsLog;
        }

        public List<LogThietBi> GetByMaThietBi(int MaThietBi)
        {
            List<LogThietBi> dsLog = new List<LogThietBi>();
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_LogThietBi_SelectByMaThietBi", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaThietBi", MaThietBi);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(reader.GetOrdinal("MaThietBi"));
                            string name = reader.GetString(reader.GetOrdinal("TenThietBi"));
                            bool status = reader.GetBoolean(reader.GetOrdinal("TinhTrang"));
                            string ip = reader.GetString(reader.GetOrdinal("Ip"));
                            string khu = reader.GetString(reader.GetOrdinal("MaKhu"));
                            int loai = reader.GetInt32(reader.GetOrdinal("LoaiThietBi"));
                            string tenKhu = reader.GetString(reader.GetOrdinal("TenKhu"));
                            string tenLoai = reader.GetString(reader.GetOrdinal("TenLoai"));
                            DateTime thoiGian = reader.GetDateTime(reader.GetOrdinal("ThoiGian"));

                            ThietBi thietbi = new ThietBi();
                            thietbi.SetIp(ip);
                            thietbi.SetMa(id);

                            thietbi.SetTinhTrang(status);
                            thietbi.SetTen(name);
                            thietbi.SetKhu(khu);
                            thietbi.SetLoai(loai);
                            thietbi.SetTenKhu(tenKhu);
                            thietbi.SetTenLoai(tenLoai);

                            LogThietBi log = new LogThietBi(thietbi, thoiGian);
                            dsLog.Add(log);
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            return dsLog;
        }
    }
}
