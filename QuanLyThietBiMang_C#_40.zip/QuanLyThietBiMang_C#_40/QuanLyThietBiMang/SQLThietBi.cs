﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public class SQLThietBi
    {
        private SqlConnection ketnoi;
        
        public SQLThietBi()
        {
            this.ketnoi = KetNoiSQL.GetConnection();
            
        }

        public void Insert(string ten, string ip, string khu, int loai)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_ThietBi_Insert", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@TenThietBi", ten);
                    cmd.Parameters.AddWithValue("@Ip", ip);
                    cmd.Parameters.AddWithValue("@MaKhu", khu);
                    cmd.Parameters.AddWithValue("@LoaiThietBi", loai);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public void Update(int ma, string ten, string ip, string khu, int loai)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_ThietBi_Update", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaThietBi", ma);
                    cmd.Parameters.AddWithValue("@TenThietBi", ten);
                    cmd.Parameters.AddWithValue("@Ip", ip);
                    cmd.Parameters.AddWithValue("@MaKhu", khu);
                    cmd.Parameters.AddWithValue("@LoaiThietBi", loai);
                    cmd.ExecuteNonQuery();
                    
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public void UpdateTinhTrang(int ma, bool tinhtrang)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_ThietBi_Update_TinhTrang", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaThietBi", ma);
                    cmd.Parameters.AddWithValue("@TinhTrang", tinhtrang);
                    ketnoi.Open();
                    cmd.ExecuteNonQuery();
                    
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            
        }

        public void Delete(int ma)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_ThietBi_Delete", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ma);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public ThietBi GetThietBiByID(int MaThietBi)
        {
            ThietBi thietbi = new ThietBi();
            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_ThietBi_SelectByID", ketnoi))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaThietBi", MaThietBi);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            thietbi.SetMa(reader.GetInt32(reader.GetOrdinal("MaThietBi")));
                            thietbi.SetTen(reader.GetString(reader.GetOrdinal("TenThietBi")));
                            thietbi.SetTinhTrang(reader.GetBoolean(reader.GetOrdinal("TinhTrang")));
                            thietbi.SetIp(reader.GetString(reader.GetOrdinal("Ip")));
                            thietbi.SetKhu(reader.GetString(reader.GetOrdinal("MaKhu")));
                            thietbi.SetLoai(reader.GetInt32(reader.GetOrdinal("LoaiThietBi")));
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            return thietbi;
        }

        public List<ThietBi> GetAll()
        {
            List<ThietBi> dsThietBi = new List<ThietBi>();
            try
            {
                using (SqlCommand command = new SqlCommand("sp_ThietBi_SelectAll", ketnoi))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(reader.GetOrdinal("MaThietBi"));
                            string name = reader.GetString(reader.GetOrdinal("TenThietBi"));
                            bool status = !reader.IsDBNull(reader.GetOrdinal("TinhTrang")) && reader.GetBoolean(reader.GetOrdinal("TinhTrang"));
                            string ip = reader.GetString(reader.GetOrdinal("Ip"));
                            string khu = reader.GetString(reader.GetOrdinal("MaKhu"));
                            int loai = reader.GetInt32(reader.GetOrdinal("LoaiThietBi"));
                            string tenKhu = reader.GetString(reader.GetOrdinal("TenKhu"));
                            string tenLoai = reader.GetString(reader.GetOrdinal("TenLoai"));
                            ThietBi thietbi = new ThietBi();
                            thietbi.SetMa(id);
                            thietbi.SetTen(name);
                            thietbi.SetTinhTrang(status);
                            thietbi.SetIp(ip);
                            thietbi.SetKhu(khu);
                            thietbi.SetLoai(loai);
                            thietbi.SetTenKhu(tenKhu);  
                            thietbi.SetTenLoai(tenLoai);
                            dsThietBi.Add(thietbi);
                        }
                    }
                }  
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            return dsThietBi;
        }
    }
}
