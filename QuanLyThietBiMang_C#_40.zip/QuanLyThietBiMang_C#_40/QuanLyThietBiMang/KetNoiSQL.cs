﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace QuanLyThietBiMang
{
    public class KetNoiSQL
    {
        private static SqlConnection connection;
        private static readonly string DB_URL = "Data Source=localhost,1433;Initial Catalog=QuanLyThietBi;User Id=MinhThy;Password=nmthy3568";

        public static SqlConnection GetConnection()
        {
            try
            {
                if (connection == null)
                {
                    connection = new SqlConnection(DB_URL);
                }
                if (connection.State != System.Data.ConnectionState.Open)
                {
                    connection.Open();
                }
                return connection;
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }

        public static void CloseConnection()
        {
            try
            {
                if (connection != null && connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
