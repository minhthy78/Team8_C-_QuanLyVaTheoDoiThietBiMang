﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThietBiMang
{
    public static class BoNhoTam
    {
        private static TaiKhoan User;

        public static TaiKhoan GetUser()
        {
            return User;
        }

        public static void SetUser(TaiKhoan tk)
        {
            User = tk;
        }
    }
}
