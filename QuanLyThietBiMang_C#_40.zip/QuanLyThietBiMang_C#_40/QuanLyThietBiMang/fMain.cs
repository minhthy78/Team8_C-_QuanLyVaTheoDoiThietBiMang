﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Threading;
using System.Data.SqlClient;

namespace QuanLyThietBiMang
{
    public partial class fMain : Form
    {
        private ScheduledThreadPoolExecutor executorService;
        private CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private System.Threading.Timer timer;
        bool sidebarExpand = true;
        public fMain()
        {
            InitializeComponent();
            sidebar.SizeChanged += sidebar_SizeChanged;
            this.Load += fMain_Load;

        }

        public class ScheduledThreadPoolExecutor
        {
            private System.Threading.Timer timer;

            public ScheduledThreadPoolExecutor(int interval, Action action)
            {
                timer = new System.Threading.Timer(state => action.Invoke(), null, 0, interval);
            }

            public void Shutdown()
            {
                timer.Dispose();
            }
        }
        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                menuButton.Image = Properties.Resources.icons8_close_24;
                sidebar.Width -= 10;
                string hoten = BoNhoTam.GetUser()?.HoTen;
                string ten = hoten.Substring(hoten.LastIndexOf(" "));
                lblHoTen.Text = ten;

                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;                   
                    sidebarTimer.Stop();
                }

            }
            else
            {
                menuButton.Image = Properties.Resources.icons8_menu_48;

                sidebar.Width += 10;
                lblHoTen.Text = BoNhoTam.GetUser()?.HoTen;



                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();

            
        }

        private void UpdateListViewSize()
        {           
            // Cập nhật chiều rộng của ListView
            tblThietBi.Width = this.Width - sidebar.Width - txtLog.Width;
            Point viTriMoi = tblThietBi.Location;
            viTriMoi.X = sidebar.Location.X + sidebar.Width;
            tblThietBi.Location = viTriMoi;
        }

        private void sidebar_SizeChanged(object sender, EventArgs e)
        {
            UpdateListViewSize();
        }

        private void InitializeProgressBar()
        {
            prgKiemTra.Style = ProgressBarStyle.Marquee;
            prgKiemTra.MarqueeAnimationSpeed = 30; // Điều chỉnh tốc độ chạy của ProgressBar
        }

       

        private void StartProgressBar()
        {
         
            timerProgress.Interval = 5000; // Đặt khoảng thời gian cần để ProgressBar chạy (đơn vị là mili giây)
            timerProgress.Tick += Timer_Tick;
            timerProgress.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Điều này sẽ được gọi khi timer đạt đến khoảng thời gian đã đặt
            // Tại đây, bạn có thể thực hiện các hành động khác sau khi ProgressBar đã chạy một khoảng thời gian nhất định
            // Ví dụ: dừng ProgressBar, hiển thị một thông báo, ...

            // Dừng ProgressBar sau khi đã chạy một khoảng thời gian nhất định
            StopProgressBar();
        }

        private void StopProgressBar()
        {
            if (timerProgress != null)
            {
                timerProgress.Stop();
                prgKiemTra.Style = ProgressBarStyle.Blocks; // Chuyển sang kiểu ProgressBar thông thường
                prgKiemTra.Value = 0; // Đặt giá trị của ProgressBar là giá trị tối đa
            }
        }

        private async void btnPing_Click(object sender, EventArgs e)
        {
            InitializeProgressBar();

            
            SQLEmail sqlMail = new SQLEmail();
            Email mailGui = sqlMail.GetEmail();

            SQLLogThietBi sqlLog = new SQLLogThietBi();
            SQLThietBi sqlThietBi = new SQLThietBi();

            SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
            List<TaiKhoan> dsTaiKhoan = sqlTaiKhoan.GetAll();
            List<string> dsEmailNhan = new List<string>();
            foreach (TaiKhoan tk in dsTaiKhoan)
            {
                dsEmailNhan.Add(tk.Email);
            }

            DataTable bangThietBi = (DataTable)tblThietBi.DataSource;
            List<string> ipAddresses = new List<string>();

            foreach (DataRow row in bangThietBi.Rows)
            {
                object ip = row[3];              
                ipAddresses.Add(ip.ToString());
            }

            

            Action pingTask = async () =>
            {
                var currentTime = DateTime.Now;
                var formattedTime = currentTime.ToString("HH:mm:ss dd/MM/yyyy");
                string logMessage = $"\n---Thời gian: {formattedTime}";

                if (txtLog.InvokeRequired)
                {
                    txtLog.Invoke((MethodInvoker)delegate {
                        txtLog.AppendText(logMessage);
                    });
                }
                else
                {
                    txtLog.AppendText(logMessage);
                }

                foreach (string ipAddress in ipAddresses)
                {
                    bool ketQuaPing = await Ping.PingDeviceAsync(ipAddress);

                    for (int i = 0; i < bangThietBi.Rows.Count; i++)
                    {
                        string ip = bangThietBi.Rows[i][3].ToString();
                        bool tinhTrangHienTai = false;
                        try
                        {
                             tinhTrangHienTai = (bool)bangThietBi.Rows[i]["TinhTrang"];
                        }
                        catch (Exception)
                        {
                            MessageBox.Show(bangThietBi.Rows[i][3].ToString());
                        }
                        
                        int maThietBi = bangThietBi.Rows[i].Field<int>("MaThietBi");

                        string kqString = ketQuaPing ? "Online" : "Offline";

                        if (ip.Equals(ipAddress))
                        {
                            string logMessage1 = $"+ {bangThietBi.Rows[i].Field<string>("TenThietBi")} -> {kqString} "  + Environment.NewLine;
                            
                            if (txtLog.InvokeRequired)
                            {
                                txtLog.Invoke((MethodInvoker)delegate {
                                    txtLog.AppendText(logMessage1);
                                });
                            }
                            else
                            {
                                txtLog.AppendText(logMessage1);
                            }
                            bangThietBi.Rows[i]["TinhTrang"] = ketQuaPing;

                            if (!tinhTrangHienTai.Equals(ketQuaPing))
                            {
                                Console.WriteLine("Có thay đổi");

                                sqlThietBi.UpdateTinhTrang(maThietBi, ketQuaPing);
                                string subject = "Thông Báo Tình Trạng Thiết Bị";
                                string message = $"\n{bangThietBi.Rows[i].Field<string>("TenThietBi")} - {ipAddress} - {kqString} - {DateTime.Now.ToString("HH:mm:ss dd/MM/yyyy")}\n";

                                EmailSender mail = new EmailSender(mailGui.EmailAddress, mailGui.Password);
                                mail.SendEmailToGroup(dsEmailNhan.ToArray(), subject, message);

                                sqlLog.Insert(maThietBi, ketQuaPing);
                            }
                        }
                    }
                }
            };

            // Lên lịch thực hiện ping mỗi 5 giây
            TimeSpan interval = TimeSpan.FromSeconds(5);
            executorService = new ScheduledThreadPoolExecutor((int)interval.TotalMilliseconds, pingTask);
            btnPing.Enabled = false;
            btnStop.Enabled = true;
        }

        private async void btnStop_Click(object sender, EventArgs e)
        {
            StopProgressBar();
            txtLog.AppendText("\n Dừng ping...\n");


            if (cancellationTokenSource != null)
            {
                cancellationTokenSource.Cancel(true);
            }

            if (executorService != null)
            {
                executorService.Shutdown();
            }
            btnPing.Enabled = true;
            btnStop.Enabled = false;
        }

        public void LoadData()
        {
            lblHoTen.Text = BoNhoTam.GetUser()?.HoTen;


            Boolean vaiTro = BoNhoTam.GetUser()?.VaiTro ?? false;

            // Vai tro: 1 Admin, 0 User
            if (!vaiTro)
            {
                btnCaiDatMail.Enabled = false;
                btnQuanLyKhu.Enabled = false;
                btnQuanLyLoai.Enabled = false;
                btnQuanLyTaiKhoan.Enabled = false;
                btnThem.Enabled = false;
                btnXoa.Enabled = false;
                btnSua.Enabled = false;
            }

            // Lấy danh sách loại từ SQL 
            
            SQLThietBi sqlThietBi = new SQLThietBi();
            List<ThietBi> dsThietBi = sqlThietBi.GetAll();


            SqlConnection ketnoi = KetNoiSQL.GetConnection();
            
            SqlCommand cmdsql = new SqlCommand("sp_ThietBi_SelectAll", ketnoi);
            cmdsql.CommandType = CommandType.StoredProcedure;


            DataTable bangThietBi = new DataTable();
            
            SqlDataAdapter adpt = new SqlDataAdapter(cmdsql);
            adpt.Fill(bangThietBi);
           
            tblThietBi.AutoGenerateColumns = false;
            tblThietBi.DataSource = bangThietBi;
        }

        private void fMain_Load(object sender, EventArgs e)
        {
            LoadData();
           

        }

        private void btnCaiDatMail_Click(object sender, EventArgs e)
        {
            fCauHinhMail fmail = new fCauHinhMail();
            fmail.Show();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            fThemThietBi fthem = new fThemThietBi();
            fthem.Show();
            fthem.FormClosed += Fthem_FormClosed;
        }

        private void Fthem_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadData();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            int dongChon = tblThietBi.SelectedCells[0].RowIndex;

            if (tblThietBi.Rows[dongChon].Cells[0].Value != null)
            {
                int MaThieBi = Convert.ToInt32(tblThietBi.Rows[dongChon].Cells[0].Value);

                fUpdateThietBi fupdate = new fUpdateThietBi();
                fupdate.SetMaThietBi(MaThieBi);
                fupdate.Show();
                fupdate.FormClosed += FUpdate_FormClosed;
            }
        }

        private void FUpdate_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (tblThietBi.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = tblThietBi.SelectedRows[0];
                int MaThieBi = (int)selectedRow.Cells[0].Value;
                SQLThietBi sqlTB = new SQLThietBi();
                sqlTB.Delete(MaThieBi);
                MessageBox.Show("Đã xóa thiết bị");
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một dòng để xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnXemLog_Click(object sender, EventArgs e)
        {
            fLog flog = new fLog();
            flog.Show();
            flog.FormClosed += FLog_FormClosed;
            
        }

        private void FLog_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadData();
        }

        private void btnQuanLyKhu_Click(object sender, EventArgs e)
        {
            fKhu fkhu = new fKhu();
            fkhu.Show();
            fkhu.FormClosed += FKhu_FormClosed;
        }
        private void FKhu_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadData();
        }

        private void btnQuanLyLoai_Click(object sender, EventArgs e)
        {
            fLoaiThietBi floaithietbi = new fLoaiThietBi();
            floaithietbi.Show();
        }

        private void btnQuanLyTaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan ftaikhoan = new fTaiKhoan();
            ftaikhoan.Show();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            fLogin flogin = new fLogin();
            flogin.Show();
            this.Close();
        }
    }
}
