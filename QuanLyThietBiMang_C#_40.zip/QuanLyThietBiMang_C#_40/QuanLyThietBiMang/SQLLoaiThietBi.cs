﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public class SQLLoaiThietBi
    {
        private SqlConnection ketnoi;

        public SQLLoaiThietBi()
        {
            this.ketnoi = KetNoiSQL.GetConnection();
        }

        public void Insert(string ten)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_LoaiThietBi_Insert", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TenLoai", ten);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public void Update(int ma, string ten)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_LoaiThietBi_Update", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MaLoai", ma);
                    command.Parameters.AddWithValue("@TenLoai", ten);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public void Delete(int ma)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_LoaiThietBi_Delete", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MaLoai", ma);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public List<LoaiThietBi> GetAll()
        {
            List<LoaiThietBi> dsLoai = new List<LoaiThietBi>();
            try
            {
                using (SqlCommand command = new SqlCommand("sp_LoaiThietBi_SelectAll", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.ExecuteNonQuery();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(0);
                            string name = reader.GetString(1);

                            LoaiThietBi loai = new LoaiThietBi();
                            loai.SetMaLoai(id);
                            loai.SetTenLoai(name);
                            dsLoai.Add(loai);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            return dsLoai;
        }
    }
}
