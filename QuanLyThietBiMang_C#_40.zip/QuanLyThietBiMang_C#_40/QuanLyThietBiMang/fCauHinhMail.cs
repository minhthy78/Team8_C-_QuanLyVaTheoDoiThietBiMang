﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fCauHinhMail : Form
    {
        public fCauHinhMail()
        {
            InitializeComponent();
            this.Load += FCauHinhMail_Load;
        }

        private void FCauHinhMail_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            SQLEmail sqlMail = new SQLEmail();
            sqlMail.Insert(txtEmail.Text, txtPasswordMail.Text);
            MessageBox.Show("Đã cập nhật thành công");
            LoadData();
            this.Close();
        }
        public void LoadData()
        {
            SQLEmail sqlMail = new SQLEmail();
            Email email = sqlMail.GetEmail();
            txtEmail.Text = email.EmailAddress;
            txtPasswordMail.Text = email.Password;
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
