﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public class SQLEmail
    {
        private SqlConnection ketnoi;

        public SQLEmail()
        {
            this.ketnoi = KetNoiSQL.GetConnection();
        }

        public void Insert(string email, string password)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_Email_Insert", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Password", password);

                    //ketnoi.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sql login: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
        }

        public Email GetEmail()
        {
            Email mailGui = new Email();
            try
            {
                using (SqlCommand command = new SqlCommand("sp_Email_Select", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //ketnoi.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string email = reader["Email"].ToString();
                            string password = reader["Password"].ToString();

                            mailGui.EmailAddress = email;
                            mailGui.Password = password;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                ketnoi.Close();
            }
            return mailGui;
        }
    }
}
