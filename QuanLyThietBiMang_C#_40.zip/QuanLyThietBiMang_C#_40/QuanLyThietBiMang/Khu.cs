﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThietBiMang
{
    public class Khu
    {
        private string MaKhu;
        private string TenKhu;

        public string GetMaKhu()
        {
            return MaKhu;
        }

        public void SetMaKhu(string MaKhu)
        {
            this.MaKhu = MaKhu;
        }

        public string GetTenKhu()
        {
            return TenKhu;
        }

        public void SetTenKhu(string TenKhu)
        {
            this.TenKhu = TenKhu;
        }

        public override string ToString()
        {
            return MaKhu + " - " + TenKhu;
        }
    }
}
