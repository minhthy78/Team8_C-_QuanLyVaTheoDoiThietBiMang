﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fKhu : Form
    {
        public fKhu()
        {
            InitializeComponent();
            this.Load += FKhu_Load;
        }
        private void FKhu_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            SQLKhu sqlKhu = new SQLKhu();
            sqlKhu.Insert(txtMaKhu.Text, txtTenKhu.Text);
            txtMaKhu.Text = "";
            txtTenKhu.Text = "";
            LoadData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            SQLKhu sqlKhu = new SQLKhu();
            int dongDangChon = tblKhu.SelectedCells[0].RowIndex;
            string maXoa = tblKhu.Rows[dongDangChon].Cells[0].Value.ToString();
            sqlKhu.Delete(maXoa);
            LoadData();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            SQLKhu sqlKhu = new SQLKhu();
            int dongDangChon = tblKhu.SelectedCells[0].RowIndex;
            string maUpdate = tblKhu.Rows[dongDangChon].Cells[0].Value.ToString();
            string tenUpdate = tblKhu.Rows[dongDangChon].Cells[1].Value.ToString();
            sqlKhu.Update(maUpdate, tenUpdate);
            LoadData();
        }

        public void LoadData()
        {
            // Lấy danh sách loại từ SQL 
            SQLKhu sqlKhu = new SQLKhu();
            List<Khu> dsKhu = sqlKhu.GetAll();

            tblKhu.Rows.Clear();       
            foreach (Khu loai in dsKhu)
            {
                tblKhu.Rows.Add( loai.GetMaKhu(), loai.GetTenKhu());
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
