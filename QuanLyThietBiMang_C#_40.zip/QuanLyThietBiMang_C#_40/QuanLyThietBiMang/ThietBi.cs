﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThietBiMang
{
    public class ThietBi
    {
        private int ma;
        private string ten;
        private bool tinhtrang;
        private string ip;
        private string khu;
        private int loai;
        private string TenKhu;
        private string TenLoai;

        public string GetTenKhu()
        {
            return TenKhu;
        }

        public void SetTenKhu(string TenKhu)
        {
            this.TenKhu = TenKhu;
        }

        public string GetTenLoai()
        {
            return TenLoai;
        }

        public void SetTenLoai(string TenLoai)
        {
            this.TenLoai = TenLoai;
        }

        public int GetMa()
        {
            return ma;
        }

        public void SetMa(int ma)
        {
            this.ma = ma;
        }

        public string GetTen()
        {
            return ten;
        }

        public void SetTen(string ten)
        {
            this.ten = ten;
        }

        public bool GetTinhTrang()
        {
            return tinhtrang;
        }

        public void SetTinhTrang(bool tinhtrang)
        {
            this.tinhtrang = tinhtrang;
        }

        public string GetIp()
        {
            return ip;
        }

        public void SetIp(string ip)
        {
            this.ip = ip;
        }

        public string GetKhu()
        {
            return khu;
        }

        public void SetKhu(string khu)
        {
            this.khu = khu;
        }

        public int GetLoai()
        {
            return loai;
        }

        public void SetLoai(int loai)
        {
            this.loai = loai;
        }

        public override string ToString()
        {
            return ten;
        }
    }
}
