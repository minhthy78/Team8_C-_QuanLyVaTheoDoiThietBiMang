﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QuanLyThietBiMang
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();          
        } 

        private void Login()
        {
            SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
            string password = txtPass.Text;

            if (string.IsNullOrEmpty(txtUser.Text) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Vui lòng nhập Username và Password", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bool login = false;
                login = sqlTaiKhoan.Login(txtUser.Text, password);

                if (login==true)
                {
                    fMain fChinh = new fMain();
                    fChinh.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sai Username hoặc Password, Vui lòng đăng nhập lại.");
                }
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Login();
            }
        }
    }
    

    
}
