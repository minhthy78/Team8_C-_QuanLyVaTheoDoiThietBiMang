﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;

namespace QuanLyThietBiMang
{
    public class Ping
    {
        public static Task<bool> PingDeviceAsync(string ipAddress)
        {
            return Task.Run(() =>
            {
                try
                {
                    System.Net.NetworkInformation.Ping ping = new System.Net.NetworkInformation.Ping();
                    var reply = ping.Send(ipAddress, 5000);

                    return reply != null && reply.Status == IPStatus.Success;
                }
                catch (Exception)
                {
                    return false;
                }
            });
        }

        public static Task<List<bool>> PingDevicesAsync(List<string> ipAddresses)
        {
            List<Task<bool>> pingTasks = new List<Task<bool>>();

            foreach (string ipAddress in ipAddresses)
            {
                pingTasks.Add(PingDeviceAsync(ipAddress));
            }

            return Task.WhenAll(pingTasks).ContinueWith(task =>
            {
                return new List<bool>(Array.ConvertAll(task.Result, result => result));
            });
        }
    }
}
