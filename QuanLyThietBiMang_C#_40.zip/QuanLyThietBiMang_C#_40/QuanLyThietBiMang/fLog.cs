﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace QuanLyThietBiMang
{
    public partial class fLog : Form
    {
        private static int MaThietBi = -1;
        public fLog()
        {
            InitializeComponent();
            this.Load += FLog_Load;
        }
        private void FLog_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void cbThietBi_SelectedIndexChanged(object sender, EventArgs e)
        {
            SQLLogThietBi sqlLog = new SQLLogThietBi();
            ThietBi thietBiChon = (ThietBi)cbThietBi.SelectedItem;
            List<LogThietBi> dsLog = sqlLog.GetByMaThietBi(thietBiChon.GetMa());

            // Initialize DataTable if it's null
            if (tblLog.DataSource == null)
            {
                DataTable bangLog = new DataTable();
                bangLog.Columns.Add("TenThietBi");
                bangLog.Columns.Add("IP");
                bangLog.Columns.Add("TinhTrang");
                bangLog.Columns.Add("ThoiGian");
                tblLog.DataSource = bangLog;
            }

             DataTable dataTable = (DataTable)tblLog.DataSource;
             dataTable.Rows.Clear(); // Clear the existing data

             foreach (LogThietBi log in dsLog)
             {
                string formattedDateTime = log.GetThoigian().ToString("dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture); 

                dataTable.Rows.Add(new object[] { log.GetThietBi().GetTen(), log.GetThietBi().GetIp(), log.GetThietBi().GetTinhTrang(), formattedDateTime });
             }
            
        }

        private void LoadData()
        {
            if (MaThietBi < 0)
            {
                // Xử lý trường hợp MaThietBi < 0 nếu cần
            }

            SQLThietBi sqlThietBi = new SQLThietBi();
            List<ThietBi> dsThietBi = sqlThietBi.GetAll();

            foreach (ThietBi tb in dsThietBi)
            {
                cbThietBi.Items.Add(tb);

                if (tb.GetMa() == MaThietBi)
                {
                    cbThietBi.SelectedItem = tb;
                }
            }
        }

    

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
