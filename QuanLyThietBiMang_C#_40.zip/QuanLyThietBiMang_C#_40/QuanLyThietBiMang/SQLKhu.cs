﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyThietBiMang
{
    public class SQLKhu
    {
        private SqlConnection ketnoi;

        public SQLKhu()
        {
            this.ketnoi = KetNoiSQL.GetConnection();
        }

        public void Insert(string ma, string ten)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_Khu_Insert", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MaKhu", ma);
                    command.Parameters.AddWithValue("@TenKhu", ten);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public void Update(string ma, string ten)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_Khu_Update", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MaKhu", ma);
                    command.Parameters.AddWithValue("@TenKhu", ten);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public void Delete(string ma)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("sp_Khu_Delete", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MaKhu", ma);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        public List<Khu> GetAll()
        {
            List<Khu> dsKhu = new List<Khu>();
            try
            {
                using (SqlCommand command = new SqlCommand("sp_Khu_SelectAll", ketnoi))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.ExecuteNonQuery();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string id = reader.GetString(0);
                            string name = reader.GetString(1);

                            Khu khu = new Khu();
                            khu.SetMaKhu(id);
                            khu.SetTenKhu(name);
                            dsKhu.Add(khu);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            return dsKhu;
        }
    }
}
