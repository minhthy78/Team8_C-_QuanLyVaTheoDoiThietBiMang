﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fTaiKhoan : Form
    {
        public fTaiKhoan()
        {
            InitializeComponent();
            this.Load += FTaiKhoan_Load;
        }

        private void FTaiKhoan_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Thêm tài khoản mới
            SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
            sqlTaiKhoan.Insert(txtUsername.Text, txtPassword.Text, txtHoTen.Text, txtEmail.Text, rdAdmin.Checked);
            LoadData();
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            // Xóa tài khoản được chọn
            int selectedRowIndex = tblTaiKhoan.SelectedCells[0].RowIndex;
            string userXoa = (string)tblTaiKhoan.Rows[selectedRowIndex].Cells[0].Value;

            DialogResult result = MessageBox.Show("Bạn có muốn xóa tài khoản này?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
                sqlTaiKhoan.Delete(userXoa);
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            // Sửa thông tin tài khoản
            int selectedRowIndex = tblTaiKhoan.SelectedCells[0].RowIndex;
            string userUpdate = (string)tblTaiKhoan.Rows[selectedRowIndex].Cells[0].Value;
            string tenUpdate = (string)tblTaiKhoan.Rows[selectedRowIndex].Cells[1].Value;
            string emailUpdate = (string)tblTaiKhoan.Rows[selectedRowIndex].Cells[2].Value;
            bool vaitroUpdate = (bool)tblTaiKhoan.Rows[selectedRowIndex].Cells[3].Value;

            SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
            sqlTaiKhoan.Update(userUpdate, tenUpdate, emailUpdate, vaitroUpdate);
            LoadData();
        }

        private void btnDoiMatKhau_Click(object sender, EventArgs e)
        {
            // Đổi mật khẩu cho tài khoản được chọn
            int selectedRowIndex = tblTaiKhoan.SelectedCells[0].RowIndex;
            string userUpdate = (string)tblTaiKhoan.Rows[selectedRowIndex].Cells[0].Value;

            fDoiMatKhau fMatKhau = new fDoiMatKhau();
            fMatKhau.LoadUser(userUpdate);
            fMatKhau.Show();
        }
        private void LoadData()
        {
            // Lấy danh sách tài khoản từ SQL 
            SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
            List<TaiKhoan> dsTaiKhoan = sqlTaiKhoan.GetAll();

            // Clear dữ liệu trong bảng
            tblTaiKhoan.Rows.Clear();

            // Thêm dữ liệu vào bảng
            foreach (TaiKhoan tk in dsTaiKhoan)
            {
                tblTaiKhoan.Rows.Add(tk.Username, tk.HoTen, tk.Email, tk.VaiTro);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
