﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fUpdateThietBi : Form
    {
        public fUpdateThietBi()
        {
            InitializeComponent();
            this.Load += fUpdateThietBi_Load;
        }
        private void fUpdateThietBi_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            LoaiThietBi loai = (LoaiThietBi)cbLoai.SelectedItem;
            Khu khu = (Khu)cbKhu.SelectedItem;

            SQLThietBi tb = new SQLThietBi();
            tb.Update(int.Parse(lblMa.Text), txtTen.Text, txtIP.Text, khu.GetMaKhu(), loai.GetMaLoai());
            MessageBox.Show("Đã cập nhật");
            this.Close();
        }

        public void SetMaThietBi(int ma)
        {
            lblMa.Text = ma.ToString();
        }

        private void loadData()
        {
            SQLThietBi sqlThietBi = new SQLThietBi();
            ThietBi thietbi = sqlThietBi.GetThietBiByID(int.Parse(lblMa.Text));

            SQLKhu sqlKhu = new SQLKhu();
            List<Khu> dsKhu = sqlKhu.GetAll();

            foreach (Khu item in dsKhu)
            {
                cbKhu.Items.Add(item);
                if (item.GetMaKhu() == thietbi.GetKhu())
                {
                    cbKhu.SelectedItem = item;
                }
            }

            SQLLoaiThietBi sqlLoai = new SQLLoaiThietBi();
            List<LoaiThietBi> dsLoai = sqlLoai.GetAll();
            foreach (LoaiThietBi item in dsLoai)
            {
                cbLoai.Items.Add(item);
                if (item.GetMaLoai() == thietbi.GetLoai())
                {
                    cbLoai.SelectedItem = item;
                }
            }

            txtTen.Text = thietbi.GetTen();
            txtIP.Text = thietbi.GetIp();
        }
    }
}
