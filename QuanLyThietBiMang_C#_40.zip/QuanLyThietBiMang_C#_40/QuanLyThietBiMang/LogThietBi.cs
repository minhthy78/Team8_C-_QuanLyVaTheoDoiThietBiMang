﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThietBiMang
{
    public class LogThietBi
    {
        private ThietBi thietbi;
        private DateTime thoigian; // Change the data type to DateTime

        public LogThietBi(ThietBi thietbi, DateTime thoigian)
        {
            this.thietbi = thietbi;
            this.thoigian = thoigian;
        }

        public ThietBi GetThietBi()
        {
            return thietbi;
        }

        public void SetThietBi(ThietBi thietbi)
        {
            this.thietbi = thietbi;
        }

        public DateTime GetThoigian() // Change the return type to DateTime
        {
            return thoigian;
        }

        public void SetThoigian(DateTime thoigian) // Change the parameter type to DateTime
        {
            this.thoigian = thoigian;
        }
    }
}
