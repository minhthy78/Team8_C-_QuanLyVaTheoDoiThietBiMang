﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThietBiMang
{
    public class TaiKhoan
    {
        /*Sử dụng thuộc tính Auto-implemented properties để đơn giản hoá 
         việc định nghĩa các thuộc tính và biến đối tượng*/
        public string Username { get; set; }
        public string Password { get; set; }
        public string HoTen { get; set; }
        public bool VaiTro { get; set; }
        public string Email { get; set; }
    }
}
