﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThietBiMang
{
    public class LoaiThietBi
    {
        private int MaLoai;
        private string TenLoai;

        public int GetMaLoai()
        {
            return MaLoai;
        }

        public void SetMaLoai(int MaLoai)
        {
            this.MaLoai = MaLoai;
        }

        public string GetTenLoai()
        {
            return TenLoai;
        }

        public void SetTenLoai(string TenLoai)
        {
            this.TenLoai = TenLoai;
        }

        // Dùng để load lên combobox
        public override string ToString()
        {
            return TenLoai;
        }
    }
}
