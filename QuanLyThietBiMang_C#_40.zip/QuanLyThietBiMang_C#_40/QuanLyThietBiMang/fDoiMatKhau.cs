﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThietBiMang
{
    public partial class fDoiMatKhau : Form
    {
        public fDoiMatKhau()
        {
            InitializeComponent();
        }
        public void LoadUser(string username)
        {
            this.lblUsername.Text = username;
        }

        private void btnDoiMatKhau_Click(object sender, EventArgs e)
        {
            SQLTaiKhoan sqlTaiKhoan = new SQLTaiKhoan();
            sqlTaiKhoan.DoiMatKhau(lblUsername.Text, txtMatKhauMoi.Text);

            MessageBox.Show("Đổi mật khẩu thành công");
            this.Close();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
